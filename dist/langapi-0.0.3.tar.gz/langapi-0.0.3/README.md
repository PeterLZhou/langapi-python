Python module for Lang API - see https://docs.langapi.co/ for more information.
